# Stadium-Seating
Visual basic Coding Challenge
Author: Cristian Benitez
